import React from "react";
import Article from "../component/Article";
import * as blogPosts from "../Data/BlogData.json";

const Articles = () => {

return (
	
		<div className="posts-container">
			{blogPosts.default.map(post => (
			<Article key={post.id} post={post} />
			))}
		</div>
);
};

export default Articles;
