import { useParams } from "react-router";
import BlogDescription from "./BlogDescription";
import * as blogPosts from "../Data/BlogData.json";
//import { useEffect, useState } from "react";

const Blog = () =>{
    
    const { id } = useParams();

    return(
        <div className="posts-container">
            {!!id &&  (
                blogPosts.default.filter(item => item.id === id).map(ele => (
                    <BlogDescription key={ele.id} post={ele} />
                ))
             )}
	    </div>
    );
}

export default Blog;