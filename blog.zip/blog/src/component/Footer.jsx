import React from "react";

const Post = () => {
return (
	<footer className="App-footer">
		<p>Copyright © Tushars Blog</p>
	</footer>
);
};

export default Post;