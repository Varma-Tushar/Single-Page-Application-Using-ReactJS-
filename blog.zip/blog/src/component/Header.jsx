import React from "react";
// import { Link } from "react-router-dom";

const Post = () => {
return (
	<header className="App-header">
        <h1>MY BLOG</h1>
      </header>
);
};

export default Post;